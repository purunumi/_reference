// 속성으로 추가된 함수 객체를 그대로 참조
var printUser = require('./node_weekend03_ex07_user7').printUser;

printUser();