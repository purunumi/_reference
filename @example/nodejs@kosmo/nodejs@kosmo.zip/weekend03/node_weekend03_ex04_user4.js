// node_weekend03_ex04_user4.js
// 익명함수 (인터페이스) 함수 객체를 그대로 할당 가능.
module.exports = function() {
    return {id:'test', name:'소녀시대'};
}