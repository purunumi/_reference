// module.exports에 할당된 클래스를 호출해서 객체 생성
var User = require('./node_weekend03_ex10_user10');
var user = new User('test01','김태리');
user.printUser();