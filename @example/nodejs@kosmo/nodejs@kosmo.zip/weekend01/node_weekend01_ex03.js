var calc = {}
calc.minus = function(a, b) {
    return a - b;
}
//console.log('calc.minus(1,2) => ', calc.minus(1,2));

module.exports = calc;

/*exports.add = function(a, b) {
    return a + b;
}*/