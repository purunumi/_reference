//weekend03_ex02_require.js

var user = require('./weekend03_ex02_exports')

console.log(user.getUser().name);