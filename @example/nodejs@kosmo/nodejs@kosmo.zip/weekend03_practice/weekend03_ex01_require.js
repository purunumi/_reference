//weekend03_ex01_require

var user = require('./weekend03_ex01_exports');

//var getUser = user.getUser;
//var group = user.group;
//console.log(getUser().name, group.name);

console.log(user.getUser().name);
console.log(user.group.name);