//weekend03_ex01_exports

//exports 전역객체에 속성을 추가하고 함수를 지정.

exports.getUser = function() {
    return {id:'test01', name:'소녀시대'};
}

exports.group = {id:'group01', name:'친구'};