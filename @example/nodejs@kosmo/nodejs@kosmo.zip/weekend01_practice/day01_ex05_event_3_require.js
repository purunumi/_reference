//node_day01_ex05_event_3_require.js

var MyClass = require('./node_day01_ex05_event_3_exports');

var mc = new MyClass()
mc.emit('stop');